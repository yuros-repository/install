#!/bin/bash

source /post/auxile
source /post/config


#HOSTNAME
header_install "Hostname and time configuration" &&
echo "creami" > /etc/hostname &&


## LOCALTIME 
ln -sf /usr/share/zoneinfo/$TIMEZONE /etc/localtime &&
hwclock --systohc &&
timedatectl set-ntp true &&
timedatectl set-timezone $TIMEZONE &&


## CONFIG
header_install "generate locales and games config" &&
cp -fr /post/base/* / &&


## LOCALE
locale-gen &&


##
## BOOTUPS
header_install "prepare boot configuration" &&
mkdir -p /boot/{efi,kernel,loader} &&
mkdir -p /boot/efi/{boot,linux,systemd,rescue} &&
mv /boot/*-ucode.img /boot/kernel/ &&
rm /etc/mkinitcpio.conf &&
rm -fr /etc/mkinitcpio.conf.d/ &&


## KERNELS
header_install "kernel installation" &&
curl -s 'https://liquorix.net/install-liquorix.sh' | sudo bash &&



## EMULATOR
header_install "emulator installation" &&

## switch
wget -O /usr/pbin/switch.AppImage https://git.ryujinx.app/api/v4/projects/1/packages/generic/Ryubing/1.3.3/ryujinx-1.3.3-x64.AppImage &&
chmod +x /usr/pbin/switch.AppImage && 

## heroic
wget -O /usr/pbin/heroic.AppImage https://github.com/Heroic-Games-Launcher/HeroicGamesLauncher/releases/download/v2.18.1/Heroic-2.18.1-linux-x86_64.AppImage &&
chmod +x /usr/pbin/heroic.AppImage  &&

## playstation 1
wget -O /usr/pbin/plays1.AppImage https://github.com/stenzek/duckstation/releases/download/latest/DuckStation-x64.AppImage &&
chmod +x /usr/pbin/plays1.AppImage &&

## playstation 2
wget -O /usr/pbin/plays2.AppImage https://github.com/PCSX2/pcsx2/releases/download/v2.4.0/pcsx2-v2.4.0-linux-appimage-x64-Qt.AppImage &&
chmod +x /usr/pbin/plays2.AppImage &&

## playstation 3
wget -O /usr/pbin/plays3.AppImage https://github.com/RPCS3/rpcs3-binaries-linux/releases/download/build-c669a0beb721d704241980675154cb35b0221d92/rpcs3-v0.0.38-18364-c669a0be_linux64.AppImage &&
chmod +x /usr/pbin/plays3.AppImage &&

## xbox 360
wget -O /usr/pbin/xbox36.AppImage https://github.com/xemu-project/xemu/releases/download/v0.8.115/xemu-v0.8.115-x86_64.AppImage &&
chmod +x /usr/pbin/xbox36.AppImage && 


##
## FIRMWARE
header_install "firmware installation" &&

## playstation 3
mkdir -p /var/games/bios/plays3 &&
wget -P /var/games/bios/plays3 https://archive.org/download/ps3-official-firmwares/Firmware%204.89/PS3UPDAT.PUP &&

## switch
mkdir -p /var/games/bios/switch &&
wget -P /var/games/bios/switch https://github.com/THZoria/NX_Firmware/releases/download/20.5.0/Firmware.20.5.0.zip &&
cd /var/games/bios/switch &&
unzip Firmware.20.5.0.zip &&
cd / &&


##
## SERVICE

header_install "enable service" &&
systemctl enable sddm &&
systemctl enable dnsmasq &&
systemctl enable sshd &&
systemctl enable update.timer &&
systemctl enable firewalld &&
systemctl enable NetworkManager &&
systemctl enable --global pipewire-pulse &&
systemctl enable systemd-timesyncd.service &&


## EXECUTE
header_install "preparing binary" &&
chmod +x /usr/xbin/* &&
chmod +x /usr/rbin/* &&
rm /usr/share/wayland-sessions/weston.desktop &&


## BOOTING
header_install "generate kernel images" &&
echo "root=$DISKPROC" > /etc/cmdline.d/01-boot.conf &&
bootctl --path=/boot install &&
mkinitcpio -P &&


## USERADD
header_install "add administrator password" &&
useradd -m $USERNAME &&
usermod -aG wheel $USERNAME &&
echo "add user passworrd" &&
passwd $USERNAME