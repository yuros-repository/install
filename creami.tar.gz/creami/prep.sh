#!/bin/bash

source /install/post/auxile
source /install/post/config


## CLEANSING
header_install "cleaning directory" &&
cleans_install


header_install "format partition" &&
mkfs.ext4 -F -q -b 4096 $DISKPROC &&
mkfs.ext4 -F -q -b 4096 $DISKDATA &&
mkfs.vfat -F32 -S 4096 -n BOOT $DISKBOOT &&


## MOUNTING
header_install "mounting filesystem" &&
mount $DISKPROC /mnt &&

mkdir -p /mnt/boot && 
mount -o uid=0,gid=0,dmask=007,fmask=007 $DISKBOOT /mnt/boot/ &&

mkdir -p /mnt/home &&
mount $DISKDATA /mnt/home &&


## MULTILIB
header_install "enable multilib packages" &&
multib_enabled;


# PROCESSOR
header_install "Package installation" &&
packer_install;
graphs_install;


# CONFIGURE
header_install "System configuration" &&
cp -fr $(pwd)/post /mnt &&
genfstab -U /mnt > /mnt/etc/fstab &&
arch-chroot /mnt /bin/bash /post/init.sh &&


# FINISHING
header_install "Finishing intallation" &&
finish_install;