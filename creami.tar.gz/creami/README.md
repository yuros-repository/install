# config-global
general configuration for creamie os


## installation

```
curl -s 'https://install.yuros.org/creami.sh' | sudo bash
```